// AudioXL - merge mods audio-metadata additions into the game's metadata at load. (｡◕‿◕｡)

module AudioXL

import Codeware.*
import Codeware.Localization.*

@if(ModuleExists("RedConsole"))
import RedConsole.*

@if(ModuleExists("RedLogger"))
import RedLogger.*

public abstract class AudioXLLog {
  @if(ModuleExists("RedLogger"))
  public static func Write(line: String) -> Void {
    RedLog.Append("AudioXL", line);
  }
  @if(!ModuleExists("RedLogger"))
  public static func Write(line: String) -> Void {}
}

public class AudioXLContribution {
  public let modName: String;
  public let resourcePath: ResRef;
  
  public let listOn: array<String>;
  public let resource: ref<audioCookedMetadataResource>;
  public let spliced: Bool;
  
  public let dropped: Bool;
}

public class AudioXLBank {
  public let name: CName;
  public let resourcePath: ResRef;
  public let resident: Bool;
  public let added: Bool;
}

public class AudioXLEvent {
  public let name: CName;
  public let wwiseId: Uint32;
  public let added: Bool;
}

public native class AudioXLNative extends IScriptable {
  public static native func Available() -> Bool
  public static native func Status() -> String
  
  public static native func IsResourceRequested(path: ResRef) -> Bool
  
  public static native func RegisterEventName(name: CName) -> Bool
  public static native func RegisterEventRow(name: CName, isLooping: Bool, minDuration: Float, maxDuration: Float, maxAttenuation: Float) -> Bool
  public static native func EventTableArmed() -> Bool
  public static native func EventTableIngested() -> Bool
  public static native func HasEventName(name: CName) -> Bool
  
  public static native func SpliceAtIngest(res: ref<audioCookedMetadataResource>) -> Bool
  public static native func MetadataSpliceArmed() -> Bool
  
  public static native func RetargetContribution(res: ref<audioCookedMetadataResource>, pathHash: Uint64) -> Int32
  
  public static native func EqAvailable() -> Bool
  public static native func EqSetEnabled(category: Int32, on: Bool) -> Void
  public static native func EqSetBand(category: Int32, band: Int32, db: Float) -> Void
  public static native func EqSetStage(category: Int32, stage: Int32) -> Void
  public static native func EqSetStageValue(category: Int32, stage: Int32, which: Int32, db: Float) -> Void
  public static native func EqApply() -> Int32
  public static native func EqStatus() -> String
  public static native func EqPresetCount() -> Int32
  public static native func EqPresetName(index: Int32) -> String
  public static native func EqPresetBand(index: Int32, band: Int32) -> Float
  
  public static native func MixCount() -> Int32
  public static native func MixKey(category: Int32) -> String
  public static native func MixSet(category: Int32, db: Float) -> Void
  public static native func MixApply() -> Int32
  public static native func MixStatus() -> String
  
  public static native func GroupCount() -> Int32
  public static native func GroupKey(group: Int32) -> String
  public static native func GroupLabel(group: Int32) -> String
  public static native func GroupSection(group: Int32) -> String
  public static native func GroupSet(group: Int32, db: Float) -> Void
  public static native func MuteCount() -> Int32
  public static native func MuteKey(mute: Int32) -> String
  public static native func MuteSection(mute: Int32) -> String
  public static native func MuteGroup(mute: Int32) -> String
  public static native func MuteLabel(mute: Int32) -> String
  public static native func MuteSize(mute: Int32) -> Int32
  public static native func MuteSet(mute: Int32, on: Bool) -> Bool
  
  public static native func NoiseEnable(on: Bool) -> Bool
  public static native func NoiseClear() -> Void
  public static native func NoiseSnapshot(max: Int32) -> Int32
  public static native func NoiseName(row: Int32) -> String
  public static native func NoiseAgeMs(row: Int32) -> Int32
  public static native func NoiseRepeats(row: Int32) -> Int32
  public static native func NoiseGroup(row: Int32) -> Int32
  public static native func NoiseMute(row: Int32) -> Int32
  public static native func NoiseMixKey(row: Int32) -> String
  
  public static native func NoiseReplay(row: Int32) -> Bool
  public static native func NoiseReport(line: String) -> Bool
  public static native func NoiseClearReport() -> Bool
  public static native func NoiseReportPath() -> String
  
  public static native func HttpAllowed() -> Bool
  public static native func HttpStatus() -> String        
  
  public static native func Poll() -> Int32               
  public static native func PendingRemote() -> Int32       
  
  public static native func StreamTitle(name: CName) -> String
  
  public static native func RegisterSound(name: CName, type: CName, path: String, gain: Float, pitch: Float, distance: Float) -> Bool
  
  public static native func RegisterSoundEx(name: CName, type: CName, path: String, gain: Float, pitch: Float, distance: Float, loop: Bool, fadeIn: Float, fadeOut: Float, start: Float, end: Float, rate: Float, stream: Bool) -> Bool
  
  public static native func RegisterSoundJson(json: String, dir: String) -> Int32
  public static native func LineType(name: CName) -> String   
  public static native func Mute(name: CName) -> Bool     
  public static native func VoiceLanguage() -> String      
  public static native func LocalisedLanguage() -> String  
  public static native func LoadManifest(path: String) -> Int32   
  
  public static native func Stop(name: CName, fadeOut: Float) -> Bool
  public static native func SetGain(name: CName, gain: Float) -> Bool
  public static native func SetGainGlide(name: CName, gain: Float, glide: Float) -> Bool   
  public static native func IsPlaying(name: CName) -> Bool
  public static native func PlayingSounds() -> array<CName>
  public static native func SetFilter(name: CName, lowPass: Float, highPass: Float) -> Bool   
  
  public static native func SetListenerMuffle(amount: Float, floorHz: Float, level: Float) -> Void
  public static native func SetPitch(name: CName, cents: Float, glide: Float) -> Bool
  public static native func SetPan(name: CName, pan: Float, glide: Float) -> Bool
  
  public static native func SetSoundEnabled(name: CName, enabled: Bool) -> Bool
  public static native func IsSoundEnabled(name: CName) -> Bool
  
  public static native func PlayFrom(name: CName, seconds: Float) -> Bool
  public static native func Position(name: CName) -> Float            
  
  public static native func Pause(name: CName, fadeOut: Float) -> Float
  
  public static native func Enabled() -> Bool
  public static native func WwiseId(name: CName) -> Uint32  
  
  public static native func LoadBank(path: String) -> Int32
  public static native func RetryBanks() -> Int32
  public static native func Duration(name: CName) -> Float            
  public static native func Subtitle(name: CName, locale: String) -> String   
  public static native func Speaker(name: CName) -> String   
  public static native func Has(name: CName) -> Bool      
  public static native func Count() -> Int32
  public static native func Report() -> array<String>     
  public static native func SlotReport() -> array<String> 
  
  public static native func CreateEmitter(name: CName, x: Float, y: Float, z: Float) -> Bool
  public static native func MoveEmitter(name: CName, x: Float, y: Float, z: Float) -> Bool
  
  public static native func AttachEmitter(name: CName, entity: ref<GameObject>) -> Bool
  public static native func DetachEmitter(name: CName) -> Bool
  public static native func IsEmitterAttached(name: CName) -> Bool
  public static native func AttachedEmitterCount() -> Int32
  public static native func TickEmitters() -> Int32
  public static native func SetEmitterReverb(name: CName, bus: CName, level: Float) -> Bool   
  public static native func SetEmitterFilter(name: CName, lowPass: Float, highPass: Float) -> Bool   
  public static native func SetEmitterOcclusion(name: CName, enabled: Bool, floorHz: Float, blockedLevel: Float) -> Bool
  public static native func SetEmitterOcclusionEx(name: CName, enabled: Bool, floorHz: Float, blockedLevel: Float, glide: Float) -> Bool
  public static native func OcclusionReport() -> String   
  
  public static native func OcclusionRay(lx: Float, ly: Float, lz: Float) -> array<Float>
  public static native func OcclusionRayResult(blocked: Bool) -> Void
  public static native func NeedsFollowTick() -> Bool
  public static native func PlayOn(emitter: CName, sound: CName, gain: Float, from: Float, fadeIn: Float) -> Bool
  public static native func ArmNextPlay(name: CName, gain: Float, fadeIn: Float) -> Bool   
  public static native func ArmNextPlayEx(name: CName, gain: Float, fadeIn: Float, pitch: Float, pan: Float) -> Bool
  public static native func PlayOnEx(emitter: CName, sound: CName, gain: Float, from: Float, fadeIn: Float, pitch: Float, pan: Float) -> Bool
  
  public static native func ArmNextPlayOpts(name: CName, gain: Float, fadeIn: Float, pitch: Float, pan: Float, delay: Float, loop: Bool, end: Float) -> Bool
  public static native func ArmNextPlayFilter(name: CName, lowPass: Float, highPass: Float) -> Bool   
  public static native func PlayOnOpts(emitter: CName, sound: CName, gain: Float, from: Float, fadeIn: Float, pitch: Float, pan: Float, delay: Float, loop: Bool, end: Float) -> Bool
  public static native func SetEmitterPitch(name: CName, cents: Float, glide: Float) -> Bool
  public static native func SetEmitterPan(name: CName, pan: Float, glide: Float) -> Bool
  public static native func StopOn(emitter: CName, sound: CName, fadeOut: Float) -> Bool      
  public static native func DestroyEmitter(name: CName) -> Bool
  public static native func DestroyAllEmitters() -> Int32
  public static native func HasEmitter(name: CName) -> Bool
  public static native func EmitterCount() -> Int32
}

public abstract class AudioXLPatcher {
  
  public let applied: Int32;
  public let missed: Int32;
  public let appliedEP1: Int32;
  public let missedEP1: Int32;

  public func Name() -> String { return "unnamed patcher"; }
  public func Apply(md: ref<audioCookedMetadataResource>) -> Void {}
  
  public func ApplyEP1(md: ref<audioCookedMetadataResource>) -> Void {}
}

public class AudioXLSound {
  public let name: CName;
  public let type: CName = n"mod_sfx_2d";
  public let file: String;
  public let gain: Float = 1.0;
  public let pitch: Float;            
  public let loop: Bool;
  public let rate: Float = 1.0;
  public let fadeIn: Float;           
  public let fadeOut: Float;
  public let fadeCurve: String;       
  public let start: Float;            
  public let end: Float;              
  public let delay: Float;            
  public let stream: Bool;
  public let resume: Bool;
  public let maxDuration: Float;
  public let maxVoices: Int32 = 4;
  public let subtitle: String;        
  public let speaker: String;
  public let lineType: String;        
  public let reverb: String;          
  public let reverbLevel: Float = 1.0;
  public let stopEvents: array<String>;
  public let lowPass: Float;          
  public let highPass: Float;
  public let pannable: Bool;          
  public let pan: Float;              
  public let randomPitch: Float;      
  public let randomPan: Float;
  public let acoustics: Bool;         
  public let category: String;        
  private let m_fileLocales: array<String>;
  private let m_fileFem: array<String>;
  private let m_fileMale: array<String>;
  private let m_subLocales: array<String>;
  private let m_subFem: array<String>;
  private let m_subMale: array<String>;

  public func AddFile(locale: String, file: String, opt maleFile: String) -> ref<AudioXLSound> {
    ArrayPush(this.m_fileLocales, locale);
    ArrayPush(this.m_fileFem, file);
    ArrayPush(this.m_fileMale, maleFile);
    return this;
  }

  public func AddSubtitle(locale: String, text: String, opt maleText: String) -> ref<AudioXLSound> {
    ArrayPush(this.m_subLocales, locale);
    ArrayPush(this.m_subFem, text);
    ArrayPush(this.m_subMale, maleText);
    return this;
  }

  public func ToJson() -> String {
    let j: String = "{" + AudioXLSound.Pair("name", NameToString(this.name));
    j += "," + AudioXLSound.Pair("type", NameToString(this.type));
    if ArraySize(this.m_fileLocales) > 0 {
      j += ",\"file\":" + AudioXLSound.Takes(this.m_fileLocales, this.m_fileFem, this.m_fileMale);
    } else if StrLen(this.file) > 0 {
      j += "," + AudioXLSound.Pair("file", this.file);
    }
    if ArraySize(this.m_subLocales) > 0 {
      j += ",\"subtitle\":" + AudioXLSound.Takes(this.m_subLocales, this.m_subFem, this.m_subMale);
    } else if StrLen(this.subtitle) > 0 {
      j += "," + AudioXLSound.Pair("subtitle", this.subtitle);
    }
    j += ",\"gain\":" + FloatToString(this.gain) + ",\"pitch\":" + FloatToString(this.pitch) + ",\"rate\":" + FloatToString(this.rate);
    j += ",\"fadeIn\":" + FloatToString(this.fadeIn) + ",\"fadeOut\":" + FloatToString(this.fadeOut);
    j += ",\"start\":" + FloatToString(this.start) + ",\"end\":" + FloatToString(this.end) + ",\"delay\":" + FloatToString(this.delay);
    j += ",\"maxDuration\":" + FloatToString(this.maxDuration) + ",\"maxVoices\":" + IntToString(this.maxVoices);
    j += ",\"reverbLevel\":" + FloatToString(this.reverbLevel) + ",\"lowPass\":" + FloatToString(this.lowPass) + ",\"highPass\":" + FloatToString(this.highPass);
    j += ",\"randomPitch\":" + FloatToString(this.randomPitch);
    if this.pannable || this.pan != 0.0 || this.randomPan > 0.0 {
      j += ",\"pan\":" + FloatToString(this.pan) + ",\"randomPan\":" + FloatToString(this.randomPan);
    }
    if this.loop { j += ",\"loop\":true"; }
    if this.stream { j += ",\"stream\":true"; }
    if this.resume { j += ",\"resume\":true"; }
    if this.acoustics { j += ",\"acoustics\":true"; }
    if StrLen(this.fadeCurve) > 0 { j += "," + AudioXLSound.Pair("fadeCurve", this.fadeCurve); }
    if StrLen(this.speaker) > 0 { j += "," + AudioXLSound.Pair("speaker", this.speaker); }
    if StrLen(this.lineType) > 0 { j += "," + AudioXLSound.Pair("lineType", this.lineType); }
    if StrLen(this.reverb) > 0 { j += "," + AudioXLSound.Pair("reverb", this.reverb); }
    if StrLen(this.category) > 0 { j += "," + AudioXLSound.Pair("category", this.category); }
    if ArraySize(this.stopEvents) > 0 {
      j += ",\"stopEvents\":[";
      let i: Int32 = 0;
      while i < ArraySize(this.stopEvents) {
        if i > 0 { j += ","; }
        j += AudioXLSound.Quote(this.stopEvents[i]);
        i += 1;
      }
      j += "]";
    }
    return j + "}";
  }

  public static func Quote(s: String) -> String {
    let t: String = StrReplaceAll(s, "\\", "\\\\");
    t = StrReplaceAll(t, "\"", "\\\"");
    t = StrReplaceAll(t, "\n", "\\n");
    t = StrReplaceAll(t, "\r", "");
    t = StrReplaceAll(t, "\t", "\\t");
    return "\"" + t + "\"";
  }

  private static func Pair(key: String, value: String) -> String {
    return "\"" + key + "\":" + AudioXLSound.Quote(value);
  }

  private static func Takes(locales: array<String>, fem: array<String>, male: array<String>) -> String {
    let out: String = "{";
    let i: Int32 = 0;
    while i < ArraySize(locales) {
      if i > 0 { out += ","; }
      let take: String = StrLen(male[i]) > 0
        ? "{" + AudioXLSound.Pair("fem", fem[i]) + "," + AudioXLSound.Pair("male", male[i]) + "}"
        : AudioXLSound.Quote(fem[i]);
      if StrLen(locales[i]) > 0 {
        out += AudioXLSound.Quote(locales[i]) + ":" + take;
      } else if StrLen(male[i]) > 0 {
        out += AudioXLSound.Pair("fem", fem[i]) + "," + AudioXLSound.Pair("male", male[i]);
      } else {
        out += AudioXLSound.Pair("", fem[i]);
      }
      i += 1;
    }
    return out + "}";
  }
}

public abstract class AudioXLAPI {
  
  public static func Register(modName: String, resource: ResRef, opt listOn: array<String>) -> Void {
    let sys = AudioXLSystem.Get();
    if !IsDefined(sys) {
      AudioXLLog.Write(s"too early to register '\(modName)'");
      return;
    }
    let c = new AudioXLContribution();
    c.modName = modName;
    c.resourcePath = resource;
    c.listOn = listOn;
    sys.Add(c);
  }

  public static func RegisterBank(name: CName, resource: ResRef, opt resident: Bool) -> Void {
    let sys = AudioXLSystem.Get();
    if !IsDefined(sys) {
      AudioXLLog.Write(s"too early to register bank '\(name)'");
      return;
    }
    sys.AddBank(name, resource, resident);
  }

  public static func RegisterEvent(name: CName) -> Void {
    let sys = AudioXLSystem.Get();
    if !IsDefined(sys) {
      AudioXLLog.Write(s"too early to register event '\(name)'");
      return;
    }
    sys.AddEvent(name, AudioXLNative.WwiseId(name));
  }

  public static func RegisterEventRow(name: CName, isLooping: Bool, minDuration: Float, maxDuration: Float, opt maxAttenuation: Float) -> Bool {
    let sys = AudioXLSystem.Get();
    if !IsDefined(sys) {
      AudioXLLog.Write(s"too early to register event '\(name)'");
      return false;
    }
    return sys.AddEventRow(name, isLooping, minDuration, maxDuration, maxAttenuation);
  }

  public static func IsEventRegistered(name: CName) -> Bool {
    return AudioXLNative.HasEventName(name);
  }

  public static func PlayLine(name: CName, opt entityID: EntityID, opt speaker: CName, opt lineType: scnDialogLineType) -> Bool {
    let gi = GetGameInstance();
    let chosen: CName = AudioXLAPI.ResolveVariant(name, gi, entityID);
    if !AudioXLNative.Has(chosen) {
      AudioXLLog.Write(s"PlayLine: no row for \(name)");
      return false;
    }
    let on: EntityID = entityID;
    if !EntityID.IsDefined(on) {
      let player = GetPlayer(gi);
      if IsDefined(player) { on = player.GetEntityID(); }
    }
    if EntityID.IsDefined(on) {
      GameInstance.GetAudioSystem(gi).Play(chosen, on, speaker);
    } else {
      GameInstance.GetAudioSystem(gi).Play(chosen);
    }
    AudioXLAPI.ShowLine(gi, chosen, speaker, on, lineType);
    return true;
  }

  public static func PlayPhoneLine(name: CName, opt entityID: EntityID, opt speaker: CName) -> Bool {
    let gi = GetGameInstance();
    let chosen: CName = AudioXLAPI.ResolveVariant(name, gi, entityID);
    if !AudioXLNative.Has(chosen) {
      AudioXLLog.Write(s"PlayPhoneLine: no row for \(name)");
      return false;
    }
    
    AudioXLNative.ArmNextPlayFilter(chosen, 5000.0, 500.0);
    let player = GetPlayer(gi);
    if IsDefined(player) {
      GameInstance.GetAudioSystem(gi).Play(chosen, player.GetEntityID(), speaker);
    } else {
      GameInstance.GetAudioSystem(gi).Play(chosen);
    }
    AudioXLAPI.ShowLine(gi, chosen, speaker, entityID, scnDialogLineType.Holocall);
    return true;
  }

  private static func ShowLine(gi: GameInstance, chosen: CName, speaker: CName, entityID: EntityID, lineType: scnDialogLineType) -> Void {
    let locale: String = NameToString(LocalizationSystem.GetInstance(gi).GetSubtitleLanguage());
    let text: String = AudioXLNative.Subtitle(chosen, locale);
    if StrLen(text) == 0 { return; }
    let who: String = AudioXLNative.Speaker(chosen);
    if StrLen(who) == 0 { who = NameToString(speaker); }
    let dur: Float = AudioXLNative.Duration(chosen);
    if dur <= 0.0 { dur = 3.0; }
    let kind: scnDialogLineType = lineType;
    if Equals(kind, scnDialogLineType.None) { kind = AudioXLAPI.LineTypeOf(chosen); }
    AudioXLSubtitles.Get(gi).Show(chosen, text, who, entityID, dur, kind);
  }

  public static func LineTypeOf(name: CName) -> scnDialogLineType {
    return AudioXLAPI.LineTypeFromString(AudioXLNative.LineType(name));
  }

  public static func LineTypeFromString(kind: String) -> scnDialogLineType {
    let k: String = StrLower(kind);
    if Equals(k, "holocall") { return scnDialogLineType.Holocall; }
    if Equals(k, "overhead") { return scnDialogLineType.OverHead; }
    if Equals(k, "radio") { return scnDialogLineType.Radio; }
    if Equals(k, "tv") || Equals(k, "globaltv") { return scnDialogLineType.GlobalTV; }
    if Equals(k, "narrator") { return scnDialogLineType.Narrator; }
    if Equals(k, "comment") || Equals(k, "scenecomment") { return scnDialogLineType.SceneComment; }
    if Equals(k, "ownerless") { return scnDialogLineType.OwnerlessRegular; }
    if Equals(k, "invisible") { return scnDialogLineType.Invisible; }
    return scnDialogLineType.Regular;
  }

  public static func ResolveVariant(name: CName, gi: GameInstance, opt entityID: EntityID) -> CName {
    let female: Bool = AudioXLAPI.IsFemale(gi, entityID);
    let want: CName = StringToName(NameToString(name) + (female ? "_f" : "_m"));
    if AudioXLNative.Has(want) { return want; }
    let other: CName = StringToName(NameToString(name) + (female ? "_m" : "_f"));
    if AudioXLNative.Has(other) { return other; }
    return name;
  }

  public static func IsFemale(gi: GameInstance, entityID: EntityID) -> Bool {
    if EntityID.IsDefined(entityID) {
      let puppet = GameInstance.FindEntityByID(gi, entityID) as gamePuppet;
      if IsDefined(puppet) { return Equals(puppet.GetResolvedGenderName(), n"Female"); }
    }
    let player = GetPlayer(gi);
    return IsDefined(player) && Equals(player.GetResolvedGenderName(), n"Female");
  }

  public static func FootwearSets() -> array<CName> {
    let sys = AudioXLSystem.Get();
    let empty: array<CName>;
    if !IsDefined(sys) { return empty; }
    return sys.FootwearSets();
  }

  public static func HasFootwearSet(set: CName) -> Bool {
    let sets: array<CName> = AudioXLAPI.FootwearSets();   
    return ArrayContains(sets, set);
  }

  public static func RegisterSound(modName: String, name: CName, type: CName, path: String,
                                   opt gain: Float, opt pitch: Float, opt distance: Float) -> Bool {
    let g: Float = gain > 0.0 ? gain : 1.0;
    let ok: Bool = AudioXLNative.RegisterSound(name, type, path, g, pitch, distance);
    let sys = AudioXLSystem.Get();
    if IsDefined(sys) {
      sys.NoteSound(modName, name, ok);
    }
    return ok;
  }

  public static func RegisterSound(modName: String, sound: ref<AudioXLSound>) -> Bool {
    if !IsDefined(sound) || !IsNameValid(sound.name) { return false; }
    let rows: Int32 = AudioXLNative.RegisterSoundJson(sound.ToJson(), "");
    let sys = AudioXLSystem.Get();
    if IsDefined(sys) {
      sys.NoteSound(modName, sound.name, rows > 0);
    }
    return rows > 0;
  }

  public static func HttpAllowed() -> Bool {
    return AudioXLNative.HttpAllowed();
  }

  public static func HttpStatus() -> String {
    return AudioXLNative.HttpStatus();
  }

  public static func PendingStations() -> Int32 {
    return AudioXLNative.PendingRemote();
  }

  public static func StreamTitle(name: CName) -> String {
    return AudioXLNative.StreamTitle(name);
  }

  public static func Stop(name: CName, opt fadeOut: Float) -> Bool {
    return AudioXLNative.Stop(name, fadeOut);
  }

  public static func SetGain(name: CName, gain: Float, opt glide: Float) -> Bool {
    if glide > 0.0 { return AudioXLNative.SetGainGlide(name, gain, glide); }
    return AudioXLNative.SetGain(name, gain);
  }

  public static func IsPlaying(name: CName) -> Bool {
    return AudioXLNative.IsPlaying(name);
  }

  public static func SetFilter(name: CName, lowPass: Float, highPass: Float) -> Bool {
    return AudioXLNative.SetFilter(name, lowPass, highPass);
  }

  public static func SetPitch(name: CName, cents: Float, opt glide: Float) -> Bool {
    return AudioXLNative.SetPitch(name, cents, glide);
  }

  public static func SetPan(name: CName, pan: Float, opt glide: Float) -> Bool {
    return AudioXLNative.SetPan(name, pan, glide);
  }

  public static func Play(name: CName, opt entityID: EntityID, opt gain: Float, opt from: Float, opt fadeIn: Float,
                          opt pitch: Float, opt pan: Float, opt delay: Float, opt loop: Bool, opt end: Float) -> Bool {
    let audio = GameInstance.GetAudioSystem(GetGameInstance());
    if !IsDefined(audio) { return false; }
    if from > 0.0 { AudioXLNative.PlayFrom(name, from); }
    if delay > 0.0 || loop || end > 0.0 {
      AudioXLNative.ArmNextPlayOpts(name, gain, fadeIn, pitch, pan, delay, loop, end);
    } else if pitch != 0.0 || pan != 0.0 {
      AudioXLNative.ArmNextPlayEx(name, gain, fadeIn, pitch, pan);
    } else {
      if gain > 0.0 || fadeIn > 0.0 { AudioXLNative.ArmNextPlay(name, gain, fadeIn); }
    }
    if EntityID.IsDefined(entityID) {
      audio.Play(name, entityID);
    } else {
      audio.Play(name);
    }
    return true;
  }

  public static func PlayingSounds() -> array<CName> {
    return AudioXLNative.PlayingSounds();
  }

  public static func SetEnabled(name: CName, enabled: Bool) -> Bool {
    return AudioXLNative.SetSoundEnabled(name, enabled);
  }

  public static func IsEnabled(name: CName) -> Bool {
    return AudioXLNative.IsSoundEnabled(name);
  }

  public static func PlayFrom(name: CName, seconds: Float) -> Bool {
    return AudioXLNative.PlayFrom(name, seconds);
  }

  public static func Position(name: CName) -> Float {
    return AudioXLNative.Position(name);
  }

  public static func Pause(name: CName, opt fadeOut: Float) -> Float {
    return AudioXLNative.Pause(name, fadeOut);
  }

  public static func Mute(modName: String, name: CName) -> Bool {
    let ok: Bool = AudioXLNative.Mute(name);
    let sys = AudioXLSystem.Get();
    if IsDefined(sys) {
      sys.NoteSound(modName, name, ok);
    }
    return ok;
  }

  public static func CreateEmitter(name: CName, pos: Vector4) -> Bool {
    return AudioXLNative.CreateEmitter(name, pos.X, pos.Y, pos.Z);
  }
  
  public static func AttachEmitter(name: CName, entity: ref<GameObject>) -> Bool {
    if !IsDefined(entity) { return false; }
    let ok: Bool = AudioXLNative.AttachEmitter(name, entity);
    if ok { AudioXLFollow.Wake(); }
    return ok;
  }

  public static func DetachEmitter(name: CName) -> Bool {
    return AudioXLNative.DetachEmitter(name);
  }

  public static func IsEmitterAttached(name: CName) -> Bool {
    return AudioXLNative.IsEmitterAttached(name);
  }

  public static func MoveEmitter(name: CName, pos: Vector4) -> Bool {
    return AudioXLNative.MoveEmitter(name, pos.X, pos.Y, pos.Z);
  }
  
  public static func SetEmitterReverb(name: CName, bus: CName, level: Float) -> Bool {
    return AudioXLNative.SetEmitterReverb(name, bus, level);
  }
  
  public static func SetEmitterFilter(name: CName, lowPass: Float, highPass: Float) -> Bool {
    return AudioXLNative.SetEmitterFilter(name, lowPass, highPass);
  }
  
  public static func SetEmitterOcclusion(name: CName, enabled: Bool, opt floorHz: Float, opt blockedLevel: Float,
                                         opt glide: Float) -> Bool {
    let ok = glide > 0.0 ? AudioXLNative.SetEmitterOcclusionEx(name, enabled, floorHz, blockedLevel, glide)
                         : AudioXLNative.SetEmitterOcclusion(name, enabled, floorHz, blockedLevel);
    if ok && enabled { AudioXLFollow.Wake(); }
    return ok;
  }
  
  public static func PlayOn(emitter: CName, sound: CName, opt gain: Float, opt from: Float, opt fadeIn: Float,
                            opt pitch: Float, opt pan: Float, opt delay: Float, opt loop: Bool, opt end: Float) -> Bool {
    
    AudioXLFollow.Wake();
    if delay > 0.0 || loop || end > 0.0 {
      return AudioXLNative.PlayOnOpts(emitter, sound, gain, from, fadeIn, pitch, pan, delay, loop, end);
    }
    if pitch != 0.0 || pan != 0.0 {
      return AudioXLNative.PlayOnEx(emitter, sound, gain, from, fadeIn, pitch, pan);
    }
    return AudioXLNative.PlayOn(emitter, sound, gain, from, fadeIn);
  }
  
  public static func SetEmitterPitch(name: CName, cents: Float, opt glide: Float) -> Bool {
    return AudioXLNative.SetEmitterPitch(name, cents, glide);
  }
  public static func SetEmitterPan(name: CName, pan: Float, opt glide: Float) -> Bool {
    return AudioXLNative.SetEmitterPan(name, pan, glide);
  }
  
  public static func StopOn(emitter: CName, opt sound: CName, opt fadeOut: Float) -> Bool {
    return AudioXLNative.StopOn(emitter, sound, fadeOut);
  }
  public static func DestroyEmitter(name: CName) -> Bool {
    return AudioXLNative.DestroyEmitter(name);
  }
  public static func HasEmitter(name: CName) -> Bool {
    return AudioXLNative.HasEmitter(name);
  }

  public static func RegisterPatcher(patcher: ref<AudioXLPatcher>) -> Void {
    let sys = AudioXLSystem.Get();
    if !IsDefined(sys) {
      AudioXLLog.Write(s"too early to register patcher '\(patcher.Name())'");
      return;
    }
    sys.AddPatcher(patcher);
  }
}

public class AudioXLSystem extends ScriptableService {

  private let m_pending: array<ref<AudioXLContribution>>;
  private let m_cooked: ref<audioCookedMetadataResource>;
  
  private let m_inBaseLoad: Bool;
  private let m_voiceChecked: Bool;   
  private let m_cookedEP1: ref<audioCookedMetadataResource>;
  private let m_tokens: array<ref<ResourceToken>>;
  private let m_log: array<String>;
  private let m_patchers: array<ref<AudioXLPatcher>>;
  private let m_banks: array<ref<AudioXLBank>>;
  private let m_events: array<ref<AudioXLEvent>>;
  
  private let m_eventsClosed: Bool;
  
  private let m_askedEvents: Bool;
  private let m_askedCooked: Bool;
  private let m_askedEP1: Bool;
  
  private let m_patched: Int32;
  private let m_patchedEP1: Int32;

  public static func Get() -> ref<AudioXLSystem> {
    return GameInstance.GetScriptableServiceContainer()
      .GetService(n"AudioXL.AudioXLSystem") as AudioXLSystem;
  }

  private func Note(msg: String) -> Void {
    ArrayPush(this.m_log, msg);
    AudioXLLog.Write(s"\(msg)");
  }

  public func Report() -> String {
    let out: String = "";
    let i: Int32 = 0;
    while i < ArraySize(this.m_log) {
      out += this.m_log[i] + "\n";
      i += 1;
    }
    return out;
  }

  public func Add(c: ref<AudioXLContribution>) -> Void {
    ArrayPush(this.m_pending, c);
    this.Note(s"registered '\(c.modName)'");
    
    let t = GameInstance.GetResourceDepot().LoadResource(c.resourcePath);
    if IsDefined(t) {
      ArrayPush(this.m_tokens, t);
      
      t.RegisterCallback(this, n"OnContributionReady");
    } else {
      this.Note(s"  '\(c.modName)': LoadResource returned nothing - is the archive installed?");
    }
  }

  private cb func OnContributionReady(token: ref<ResourceToken>) -> Void {
    let c = this.MatchContribution(token.GetPath());
    if !IsDefined(c) || IsDefined(c.resource) {
      return;   
    }
    let res = token.GetResource() as audioCookedMetadataResource;
    if !IsDefined(res) {
      this.Note(s"  '\(c.modName)': resource did not load - is the archive installed?");
      return;
    }
    c.resource = res;
    this.Note(s"'\(c.modName)': contribution loaded (late path), \(ArraySize(res.entries)) entries");
    this.SpliceReady();
  }

  private cb func OnLoad() {
    let cb = GameInstance.GetCallbackSystem();
    cb.RegisterCallback(n"Resource/Load", this, n"OnResourceLoad")
      .AddTarget(ResourceTarget.Type(n"audioCookedMetadataResource"));
    cb.RegisterCallback(n"Resource/Load", this, n"OnSoundBanks")
      .AddTarget(ResourceTarget.Path(r"base\\sound\\event\\soundbanks.json"));
    cb.RegisterCallback(n"Resource/Load", this, n"OnEventTable")
      .AddTarget(ResourceTarget.Path(r"base\\sound\\event\\eventsmetadata.json"));
    this.Note("listening on Resource/Load for audioCookedMetadataResource + soundbanks.json");
    
    cb.RegisterCallback(n"Session/Ready", this, n"OnSessionReadyBanks");
    
    cb.RegisterCallback(n"Session/BeforeEnd", this, n"OnSessionEndEmitters");
    this.Note(s"native: \(AudioXLNative.Status())");
    
    this.AddEvent(n"axl_voice_2d", AudioXLNative.WwiseId(n"axl_voice_2d"));
    this.AddEvent(n"axl_music_2d", AudioXLNative.WwiseId(n"axl_music_2d"));
    this.AddEvent(n"axl_radio_2d", AudioXLNative.WwiseId(n"axl_radio_2d"));
    this.AddEvent(n"axl_sfx_2d", AudioXLNative.WwiseId(n"axl_sfx_2d"));
    this.AddEvent(n"axl_master_2d", AudioXLNative.WwiseId(n"axl_master_2d"));
    this.AddEvent(n"axl_radioport_2d", AudioXLNative.WwiseId(n"axl_radioport_2d"));
    
    this.AddEvent(n"axl_radio_3d", AudioXLNative.WwiseId(n"axl_radio_3d"));
    this.AddEvent(n"axl_radio_veh3d", AudioXLNative.WwiseId(n"axl_radio_veh3d"));
    
    this.AddEvent(n"axl_music_3d", AudioXLNative.WwiseId(n"axl_music_3d"));
    
    this.AddEvent(n"axl_voice_2d_acoustics", AudioXLNative.WwiseId(n"axl_voice_2d_acoustics"));

    this.RequestMetadata(true);
  }

  private cb func OnInitialize() {
    this.RequestMetadata(false);
  }

  private func RequestMetadata(onlyIfRequested: Bool) -> Void {
    let depot = GameInstance.GetResourceDepot();
    let when: String = onlyIfRequested ? "at OnLoad, already requested by another mod" : "at OnInitialize";

    let events: ResRef = r"base\\sound\\event\\eventsmetadata.json";
    if !AudioXLNative.EventTableArmed() && !this.m_askedEvents && !this.m_eventsClosed
       && (!onlyIfRequested || AudioXLNative.IsResourceRequested(events)) {
      this.m_askedEvents = true;
      this.Note(s"requesting the events table (\(when))");
      let et = depot.LoadResource(events);
      if IsDefined(et) {
        ArrayPush(this.m_tokens, et);
        et.RegisterCallback(this, n"OnEventTableReady");
      }
    }

    let base: ResRef = r"base\\sound\\metadata\\cooked_metadata.audio_metadata";
    if !this.m_askedCooked && !IsDefined(this.m_cooked)
       && (!onlyIfRequested || AudioXLNative.IsResourceRequested(base)) {
      this.m_askedCooked = true;
      this.Note(s"requesting the base metadata (\(when))");
      let t = depot.LoadResource(base);
      if IsDefined(t) {
        ArrayPush(this.m_tokens, t);
        t.RegisterCallback(this, n"OnCookedReady");
      } else {
        this.Note("  WARNING: could not request the base metadata");
      }
    }

    let ep1: ResRef = r"ep1\\sound\\metadata\\cooked_metadata.audio_metadata";
    if !this.m_askedEP1 && !IsDefined(this.m_cookedEP1)
       && (!onlyIfRequested || AudioXLNative.IsResourceRequested(ep1)) {
      this.m_askedEP1 = true;
      this.Note(s"requesting the EP1 metadata (\(when))");
      let e1 = depot.LoadResource(ep1);
      if IsDefined(e1) {
        ArrayPush(this.m_tokens, e1);
        e1.RegisterCallback(this, n"OnCookedEP1Ready");
      }
    }
  }

  private cb func OnResourceLoad(event: ref<ResourceEvent>) {
    let res = event.GetResource() as audioCookedMetadataResource;
    if !IsDefined(res) {
      return;
    }
    let c = this.MatchContribution(event.GetPath());
    if IsDefined(c) {
      c.resource = res;
      this.Note(s"'\(c.modName)': contribution loaded, \(ArraySize(res.entries)) entries");
      this.SpliceReady();
      return;
    }
    
    if Equals(ResRef.GetHash(event.GetPath()),
              ResRef.GetHash(r"base\\sound\\metadata\\cooked_metadata.audio_metadata")) {
      this.m_cooked = res;
      this.Note(s"base metadata via Resource/Load (EARLY path), \(ArraySize(res.entries)) entries");
      this.m_inBaseLoad = true;
      this.SpliceReady();
      this.m_inBaseLoad = false;
    } else {
      if Equals(ResRef.GetHash(event.GetPath()),
                ResRef.GetHash(r"ep1\\sound\\metadata\\cooked_metadata.audio_metadata")) {
        this.m_cookedEP1 = res;
        this.Note(s"EP1 metadata via Resource/Load (EARLY path), \(ArraySize(res.entries)) entries");
        
        this.RunPatchers();
      } else {
        this.Note(s"ignoring another audioCookedMetadataResource (\(ArraySize(res.entries)) entries)");
      }
    }
  }

  private cb func OnCookedReady(token: ref<ResourceToken>) {
    if IsDefined(this.m_cooked) {
      return;   
    }
    let res = token.GetResource() as audioCookedMetadataResource;
    if !IsDefined(res) {
      this.Note("token delivered the metadata but the cast failed");
      return;
    }
    this.m_cooked = res;
    this.Note(s"base metadata via TOKEN (late path), \(ArraySize(res.entries)) entries");
    this.SpliceReady();
  }

  private cb func OnCookedEP1Ready(token: ref<ResourceToken>) {
    if IsDefined(this.m_cookedEP1) {
      return;
    }
    let res = token.GetResource() as audioCookedMetadataResource;
    if !IsDefined(res) {
      return;   
    }
    this.m_cookedEP1 = res;
    this.Note(s"EP1 metadata via TOKEN (late path), \(ArraySize(res.entries)) entries");
    this.RunPatchers();
  }

  private func SpliceReady() -> Void {
    if !IsDefined(this.m_cooked) {
      return;
    }
    let i: Int32 = 0;
    while i < ArraySize(this.m_pending) {
      let c = this.m_pending[i];
      if !c.spliced && !c.dropped && IsDefined(c.resource) {
        AudioXLNative.RetargetContribution(c.resource, ResRef.GetHash(c.resourcePath));
        if this.m_inBaseLoad || !AudioXLNative.MetadataSpliceArmed() {
          c.spliced = true;
          let n: Int32 = 0;
          let j: Int32 = 0;
          while j < ArraySize(c.resource.entries) {
            ArrayPush(this.m_cooked.entries, c.resource.entries[j]);
            n += 1;
            j += 1;
          }
          this.Note(s"'\(c.modName)': spliced \(n) entries, base now \(ArraySize(this.m_cooked.entries))");
          this.ApplyListOn(c);
        } else {
          if AudioXLNative.SpliceAtIngest(c.resource) {
            c.spliced = true;
            this.Note(s"'\(c.modName)': \(ArraySize(c.resource.entries)) entries go in at the game's load (late path)");
            this.ApplyListOn(c);
          } else {
            c.dropped = true;
            this.Note(s"'\(c.modName)': NOT added - the game had already loaded its sound records");
          }
        }
      }
      i += 1;
    }
    
    this.RunPatchers();
  }

  public func NoteSound(modName: String, name: CName, ok: Bool) -> Void {
    if ok {
      this.Note(s"'\(modName)': sound \(name) registered (\(AudioXLNative.Count()) rows)");
    } else {
      this.Note(s"'\(modName)': sound \(name) NOT registered - see red4ext/logs/AudioXL");
    }
  }

  public func AddBank(name: CName, resource: ResRef, resident: Bool) -> Void {
    let b = new AudioXLBank();
    b.name = name;
    b.resourcePath = resource;
    b.resident = resident;
    ArrayPush(this.m_banks, b);
    this.Note(s"registered bank '\(name)'");
  }

  private cb func OnSoundBanks(event: ref<ResourceEvent>) {
    let res = event.GetResource() as SoundBanksJson;
    if !IsDefined(res) {
      return;
    }
    let before: Int32 = ArraySize(res.soundBanks);
    let i: Int32 = 0;
    while i < ArraySize(this.m_banks) {
      let b = this.m_banks[i];
      if !b.added {
        b.added = true;
        let e: SoundBankEntry;
        e.name = b.name;
        e.isResident = b.resident;
        e.resourcePath = b.resourcePath;
        ArrayPush(res.soundBanks, e);
      }
      i += 1;
    }
    this.Note(s"soundbanks.json: \(before) banks -> \(ArraySize(res.soundBanks)) after our additions");
  }

  private cb func OnSessionReadyBanks(event: ref<GameSessionEvent>) -> Void {
    let n: Int32 = AudioXLNative.RetryBanks();
    if n > 0 {
      this.Note(s"banks: \(n) loaded at session start");
    }
    this.CheckVoiceLanguage();
  }

  private func CheckVoiceLanguage() -> Void {
    if this.m_voiceChecked { return; }
    this.m_voiceChecked = true;
    let loaded: String = AudioXLNative.LocalisedLanguage();
    if StrLen(loaded) == 0 { return; }
    let setting = GameInstance.GetSettingsSystem(GetGameInstance()).GetVar(n"/language", n"VoiceOver") as ConfigVarListName;
    if !IsDefined(setting) { return; }
    let spoken: String = NameToString(setting.GetValue());
    if NotEquals(StrLower(spoken), loaded) {
      this.Note(s"voice language: the game speaks \(spoken) but sounds made per language were loaded in \(loaded); restart the game to hear \(spoken)");
    }
  }

  private cb func OnSessionEndEmitters(event: ref<GameSessionEvent>) -> Void {
    let n: Int32 = AudioXLNative.DestroyAllEmitters();
    if n > 0 {
      this.Note(s"emitters: \(n) destroyed at session end");
    }
  }

  public func AddEvent(name: CName, wwiseId: Uint32) -> Void {
    if AudioXLNative.EventTableArmed() {
      if AudioXLNative.RegisterEventName(name) {
        this.Note(s"registered event '\(name)' (wwiseId \(wwiseId))");
      } else {
        this.Note(s"event '\(name)' NOT added: the events table was already loaded - register from your OnLoad");
      }
      return;
    }
    let e = new AudioXLEvent();
    e.name = name;
    e.wwiseId = wwiseId;
    ArrayPush(this.m_events, e);
    if this.m_eventsClosed {
      this.Note(s"event '\(name)' NOT added: the events table was already loaded - register from your OnLoad");
    } else {
      this.Note(s"registered event '\(name)' (wwiseId \(wwiseId))");
    }
  }

  public func AddEventRow(name: CName, isLooping: Bool, minDuration: Float, maxDuration: Float, maxAttenuation: Float) -> Bool {
    if !AudioXLNative.EventTableArmed() {
      this.Note(s"event '\(name)' NOT added: no native event table on this game version");
      return false;
    }
    let ok = AudioXLNative.RegisterEventRow(name, isLooping, minDuration, maxDuration, maxAttenuation);
    if ok {
      this.Note(s"registered event row '\(name)' (\(minDuration)-\(maxDuration) s)");
    } else {
      this.Note(s"event '\(name)' NOT added: the events table was already loaded - register from your OnLoad");
    }
    return ok;
  }

  private cb func OnEventTable(event: ref<ResourceEvent>) {
    if AudioXLNative.EventTableArmed() || this.m_eventsClosed { return; }
    let res = event.GetResource() as JsonResource;
    if !IsDefined(res) { return; }
    let root = res.root as audioAudioEventArray;
    if !IsDefined(root) { return; }
    this.m_eventsClosed = true;
    this.Note(s"events table via Resource/Load, \(ArraySize(root.events)) entries");
    this.AddPendingEvents(root);
  }

  private cb func OnEventTableReady(token: ref<ResourceToken>) {
    if AudioXLNative.EventTableArmed() || this.m_eventsClosed { return; }
    this.m_eventsClosed = true;
    if ArraySize(this.m_events) > 0 {
      this.Note(s"WARNING: the events table loaded before AudioXL could listen; \(ArraySize(this.m_events)) event names are NOT registered");
    }
  }

  private func AddPendingEvents(table: ref<audioAudioEventArray>) -> Void {
    if ArraySize(table.events) == 0 { return; }
    let added: Int32 = 0;
    let i: Int32 = 0;
    while i < ArraySize(this.m_events) {
      let e = this.m_events[i];
      if !e.added {
        e.added = true;
        let row = table.events[0];
        row.redId = e.name;
        row.wwiseId = e.wwiseId;
        ArrayPush(table.events, row);
        added += 1;
      }
      i += 1;
    }
    if added > 0 {
      this.Note(s"events table: +\(added), now \(ArraySize(table.events)) entries");
    }
  }

  public func AddPatcher(patcher: ref<AudioXLPatcher>) -> Void {
    ArrayPush(this.m_patchers, patcher);
    this.Note(s"registered patcher '\(patcher.Name())'");
    
    this.RunPatchers();
  }

  private func RunPatchers() -> Void {
    if IsDefined(this.m_cooked) {
      while this.m_patched < ArraySize(this.m_patchers) {
        let p = this.m_patchers[this.m_patched];
        this.m_patched += 1;
        p.Apply(this.m_cooked);
        if p.missed > 0 {
          this.Note(s"  patcher '\(p.Name())': \(p.applied) records edited, \(p.missed) NOT FOUND");
        } else {
          this.Note(s"  patcher '\(p.Name())': \(p.applied) records edited");
        }
      }
    }
    if IsDefined(this.m_cookedEP1) {
      while this.m_patchedEP1 < ArraySize(this.m_patchers) {
        let p = this.m_patchers[this.m_patchedEP1];
        this.m_patchedEP1 += 1;
        p.ApplyEP1(this.m_cookedEP1);
        
        if p.missedEP1 > 0 {
          this.Note(s"  patcher '\(p.Name())': EP1 \(p.appliedEP1) records edited, \(p.missedEP1) NOT FOUND");
        } else {
          if p.appliedEP1 > 0 {
            this.Note(s"  patcher '\(p.Name())': EP1 \(p.appliedEP1) records edited");
          }
        }
      }
    }
  }

  public func FindRecord(md: ref<audioCookedMetadataResource>, name: CName) -> ref<audioAudioMetadata> {
    if !IsDefined(md) {
      return null;
    }
    let i: Int32 = 0;
    while i < ArraySize(md.entries) {
      if Equals(md.entries[i].name, name) {
        return md.entries[i];
      }
      i += 1;
    }
    return null;
  }

  private func MatchContribution(path: ResRef) -> ref<AudioXLContribution> {
    let i: Int32 = 0;
    let hit: ref<AudioXLContribution>;
    while i < ArraySize(this.m_pending) {
      if Equals(ResRef.GetHash(this.m_pending[i].resourcePath), ResRef.GetHash(path)) {
        hit = this.m_pending[i];
      }
      i += 1;
    }
    return hit;
  }

  private func ApplyListOn(c: ref<AudioXLContribution>) -> Void {
    let listed: Int32 = 0;
    let dupes: Int32 = 0;
    let i: Int32 = 0;
    while i < ArraySize(c.listOn) {
      let pair: String = c.listOn[i];
      if StrContains(pair, "=") {
        let matName: CName = StringToName(StrBeforeFirst(pair, "="));
        let recName: CName = StringToName(StrAfterFirst(pair, "="));
        let fs = this.FindFootsteps(matName);
        if IsDefined(fs) {
          
          if !ArrayContains(fs.footwearMetadataArray, recName) {
            ArrayPush(fs.footwearMetadataArray, recName);
            listed += 1;
          } else {
            dupes += 1;
          }
        } else {
          this.Note(s"  '\(c.modName)': material \(matName) not found");
        }
      } else {
        
        this.Note(s"  '\(c.modName)': listOn entry '\(pair)' is not a pair - it must read " +
                  s"vanilla_material=your_record (e.g. lcm_footsteps_concrete=lcm_concrete_mine). " +
                  s"Only footwear records need listOn; leave it out for anything else.");
      }
      i += 1;
    }
    if listed > 0 || dupes > 0 {
      let extra: String = dupes > 0 ? s", \(dupes) already listed by another mod" : "";
      this.Note(s"  '\(c.modName)': listed on \(listed) materials" + extra);
    }
  }

  public func FootwearSets() -> array<CName> {
    let out: array<CName>;
    let i: Int32 = 0;
    while i < ArraySize(this.m_pending) {
      let c: ref<AudioXLContribution> = this.m_pending[i];
      if c.spliced {
        let j: Int32 = 0;
        while j < ArraySize(c.listOn) {
          let pair: String = c.listOn[j];
          if StrContains(pair, "=") {
            let mat: String = StrAfterFirst(StrBeforeFirst(pair, "="), "lcm_footsteps_");
            let rec: String = StrAfterFirst(pair, "=");
            let prefix: String = "lcm_" + mat + "_";
            if StrLen(mat) > 0 && StrBeginsWith(rec, prefix) {
              let set: CName = StringToName(StrAfterFirst(rec, prefix));
              if NotEquals(set, n"") && !ArrayContains(out, set) { ArrayPush(out, set); }
            }
          }
          j += 1;
        }
      }
      i += 1;
    }
    return out;
  }

  private func FindFootsteps(name: CName) -> ref<audioFootstepsMetadata> {
    let i: Int32 = 0;
    let hit: ref<audioFootstepsMetadata>;
    while i < ArraySize(this.m_cooked.entries) {
      let fs = this.m_cooked.entries[i] as audioFootstepsMetadata;
      if IsDefined(fs) && Equals(fs.name, name) {
        hit = fs;
      }
      i += 1;
    }
    return hit;
  }
}

public class AudioXLSubtitles extends ScriptableSystem {
  private let m_delay: DelayID;
  private let m_line: scnDialogLineData;
  private let m_active: Bool;

  public static func Get(gi: GameInstance) -> ref<AudioXLSubtitles> {
    return GameInstance.GetScriptableSystemsContainer(gi).Get(n"AudioXL.AudioXLSubtitles") as AudioXLSubtitles;
  }

  public func Show(name: CName, text: String, speaker: String, entityID: EntityID, duration: Float, opt lineType: scnDialogLineType) -> Void {
    let gi = this.GetGameInstance();
    this.Hide();
    let line: scnDialogLineData;
    line.duration = duration;
    line.id = CreateCRUID(StringToUint64(NameToString(name)));
    line.isPersistent = false;
    if EntityID.IsDefined(entityID) {
      line.speaker = GameInstance.FindEntityByID(gi, entityID) as GameObject;
    }
    line.speakerName = speaker;
    line.text = text;
    line.type = Equals(lineType, scnDialogLineType.None) ? scnDialogLineType.Regular : lineType;
    let board = GameInstance.GetBlackboardSystem(gi).Get(GetAllBlackboardDefs().UIGameData);
    board.SetVariant(GetAllBlackboardDefs().UIGameData.ShowDialogLine, ToVariant([line]), true);
    this.m_line = line;
    this.m_active = true;
    let cb = new AudioXLHideLineCallback();
    cb.system = this;
    this.m_delay = GameInstance.GetDelaySystem(gi).DelayCallback(cb, duration);
  }

  public func Hide() -> Void {
    let gi = this.GetGameInstance();
    if this.m_active {
      let board = GameInstance.GetBlackboardSystem(gi).Get(GetAllBlackboardDefs().UIGameData);
      board.SetVariant(GetAllBlackboardDefs().UIGameData.HideDialogLine, ToVariant([this.m_line.id]), true);
      this.m_active = false;
    }
    if NotEquals(this.m_delay, GetInvalidDelayID()) {
      GameInstance.GetDelaySystem(gi).CancelCallback(this.m_delay);
      this.m_delay = GetInvalidDelayID();
    }
  }
}

public class AudioXLHideLineCallback extends DelayCallback {
  public let system: wref<AudioXLSubtitles>;
  public func Call() -> Void {
    if IsDefined(this.system) { this.system.Hide(); }
  }
}

@if(ModuleExists("RedConsole"))
public class AudioXLStatusCmd extends RedConsoleCmd {
  public func Name() -> String { return "audioxl"; }
  public func Help() -> String { return "what AudioXL registered and spliced this session"; }
  public func Run(gi: GameInstance, args: array<String>) -> String {
    let sys = AudioXLSystem.Get();
    if !IsDefined(sys) {
      return "AudioXL system not running";
    }
    let out: String = sys.Report();
    let lines: array<String> = AudioXLNative.Report();
    let i: Int32 = 0;
    out += s"native: \(AudioXLNative.Status()), \(AudioXLNative.Count()) rows, \(AudioXLNative.EmitterCount()) emitters
";
    while i < ArraySize(lines) {
      out += lines[i] + "
";
      i += 1;
    }
    return out;
  }
}

@if(ModuleExists("RedConsole"))
public class AudioXLConsoleHook extends ScriptableService {
  private cb func OnInitialize() {
    GameInstance.GetCallbackSystem().RegisterCallback(n"Session/Ready", this, n"OnSessionReady");
  }
  private cb func OnSessionReady(event: ref<GameSessionEvent>) -> Void {
    RedConsoleAPI.Register(GetGameInstance(), new AudioXLStatusCmd());
  }
}

public class AudioXLFollowTick extends DelayCallback {
  public func Call() -> Void {
    AudioXLFollow.Run();
  }
}

public class AudioXLListener extends ScriptableService {
  private let m_player: wref<PlayerPuppet>;
  private let m_psm: wref<IBlackboard>;
  private let m_listener: ref<CallbackHandle>;

  public final static func Get() -> ref<AudioXLListener> {
    return GameInstance.GetScriptableServiceContainer().GetService(n"AudioXL.AudioXLListener") as AudioXLListener;
  }

  public final static func Watch(player: ref<PlayerPuppet>) -> Void {
    let self = AudioXLListener.Get();
    if IsDefined(self) { self.Follow(player); }
  }

  public final static func Unwatch(player: ref<PlayerPuppet>) -> Void {
    let self = AudioXLListener.Get();
    if IsDefined(self) && self.m_player == player { self.Drop(); }
  }

  private func Follow(player: ref<PlayerPuppet>) -> Void {
    this.Drop();
    let psm = player.GetPlayerStateMachineBlackboard();
    if !IsDefined(psm) { return; }
    this.m_player = player;
    this.m_psm = psm;
    this.m_listener = psm.RegisterListenerInt(GetAllBlackboardDefs().PlayerStateMachine.Swimming, this, n"OnSwimming");
    this.Apply(psm.GetInt(GetAllBlackboardDefs().PlayerStateMachine.Swimming));
  }

  private func Drop() -> Void {
    if IsDefined(this.m_psm) && IsDefined(this.m_listener) {
      this.m_psm.UnregisterListenerInt(GetAllBlackboardDefs().PlayerStateMachine.Swimming, this.m_listener);
    }
    this.m_listener = null;
    this.m_psm = null;
    this.m_player = null;
    AudioXLNative.SetListenerMuffle(0.0, 600.0, 0.5);
  }

  protected cb func OnSwimming(value: Int32) -> Bool {
    this.Apply(value);
    return true;
  }

  private func Apply(value: Int32) -> Void {
    let diving = Equals(IntEnum<gamePSMSwimming>(value), gamePSMSwimming.Diving);
    AudioXLNative.SetListenerMuffle(diving ? 1.0 : 0.0, 600.0, 0.5);
  }
}

@wrapMethod(PlayerPuppet)
protected cb func OnGameAttached() -> Bool {
  let result = wrappedMethod();
  AudioXLListener.Watch(this);
  return result;
}

@wrapMethod(PlayerPuppet)
protected cb func OnDetach() -> Bool {
  AudioXLListener.Unwatch(this);
  return wrappedMethod();
}

public class AudioXLFollow extends ScriptableService {
  private let m_running: Bool;
  private let m_rayStep: Int32;

  public final static func Get() -> ref<AudioXLFollow> {
    return GameInstance.GetScriptableServiceContainer().GetService(n"AudioXL.AudioXLFollow") as AudioXLFollow;
  }

  public final static func Wake() -> Void {
    let self = AudioXLFollow.Get();
    if IsDefined(self) { self.Start(); }
  }

  public final static func Run() -> Void {
    let self = AudioXLFollow.Get();
    if IsDefined(self) { self.Step(); }
  }

  private func Start() -> Void {
    if this.m_running { return; }
    this.m_running = true;
    this.Arm();
  }

  private func Arm() -> Void {
    this.ArmIn(AudioXLFollow.Interval());
  }

  private func ArmIn(seconds: Float) -> Void {
    let gi = GetGameInstance();
    let delay = GameInstance.GetDelaySystem(gi);
    if !IsDefined(delay) {
      
      this.m_running = false;
      return;
    }
    GameInstance.GetDelaySystem(gi).DelayCallback(new AudioXLFollowTick(), seconds);
  }

  private func Step() -> Void {
    if !AudioXLNative.NeedsFollowTick() {
      this.m_running = false;     
      return;
    }
    if AudioXLNative.AttachedEmitterCount() > 0 {
      AudioXLNative.TickEmitters();
      
      this.m_rayStep += 1;
      if this.m_rayStep >= 3 {
        this.m_rayStep = 0;
        this.CastOcclusionRay();
      }
      this.Arm();
      return;
    }
    this.CastOcclusionRay();
    this.ArmIn(AudioXLFollow.RayInterval());   
  }

  private func CastOcclusionRay() -> Void {
    let gi = GetGameInstance();
    let cam: Transform;
    if !GameInstance.GetCameraSystem(gi).GetActiveCameraWorldTransform(cam) { return; }
    let from: Vector4 = Transform.GetPosition(cam);
    let to: array<Float> = AudioXLNative.OcclusionRay(from.X, from.Y, from.Z);
    if ArraySize(to) < 3 { return; }
    
    if ArraySize(to) >= 6 { from = new Vector4(to[3], to[4], to[5], 1.0); }
    let hit: TraceResult;
    GameInstance.GetSpatialQueriesSystem(gi).SyncRaycastByCollisionPreset(from, new Vector4(to[0], to[1], to[2], 1.0), n"World Static", hit);
    AudioXLNative.OcclusionRayResult(TraceResult.IsValid(hit));
  }

  public final static func Interval() -> Float { return 0.033; }
  public final static func RayInterval() -> Float { return 0.1; }
}
