module AudioXL
// AudioXL for Lua (CET) mods. (｡･ω･)ﾉﾞ

public class AudioXLLua extends ScriptableSystem {

  public func Play(name: String, opt entityID: EntityID, opt gain: Float, opt from: Float, opt fadeIn: Float,
                   opt pitch: Float, opt pan: Float, opt delay: Float, opt loop: Bool, opt end: Float) -> Bool {
    return AudioXLAPI.Play(StringToName(name), entityID, gain, from, fadeIn, pitch, pan, delay, loop, end);
  }

  public func PlayLine(name: String, opt entityID: EntityID, opt speaker: String, opt lineType: String) -> Bool {
    let kind: scnDialogLineType = StrLen(lineType) > 0 ? AudioXLAPI.LineTypeFromString(lineType) : scnDialogLineType.None;
    return AudioXLAPI.PlayLine(StringToName(name), entityID, StringToName(speaker), kind);
  }

  public func PlayPhoneLine(name: String, opt entityID: EntityID, opt speaker: String) -> Bool {
    return AudioXLAPI.PlayPhoneLine(StringToName(name), entityID, StringToName(speaker));
  }

  public func Stop(name: String, opt fadeOut: Float) -> Bool {
    return AudioXLAPI.Stop(StringToName(name), fadeOut);
  }

  public func Pause(name: String, opt fadeOut: Float) -> Float {
    return AudioXLAPI.Pause(StringToName(name), fadeOut);
  }

  public func PlayFrom(name: String, seconds: Float) -> Bool {
    return AudioXLAPI.PlayFrom(StringToName(name), seconds);
  }

  public func SetGain(name: String, gain: Float, opt glide: Float) -> Bool {
    return AudioXLAPI.SetGain(StringToName(name), gain, glide);
  }

  public func SetFilter(name: String, lowPass: Float, highPass: Float) -> Bool {
    return AudioXLAPI.SetFilter(StringToName(name), lowPass, highPass);
  }

  public func SetPitch(name: String, cents: Float, opt glide: Float) -> Bool {
    return AudioXLAPI.SetPitch(StringToName(name), cents, glide);
  }

  public func SetPan(name: String, pan: Float, opt glide: Float) -> Bool {
    return AudioXLAPI.SetPan(StringToName(name), pan, glide);
  }

  public func SetEnabled(name: String, enabled: Bool) -> Bool {
    return AudioXLAPI.SetEnabled(StringToName(name), enabled);
  }

  public func IsEnabled(name: String) -> Bool {
    return AudioXLAPI.IsEnabled(StringToName(name));
  }

  public func Has(name: String) -> Bool {
    return AudioXLNative.Has(StringToName(name));
  }

  public func IsPlaying(name: String) -> Bool {
    return AudioXLAPI.IsPlaying(StringToName(name));
  }

  public func Position(name: String) -> Float {
    return AudioXLAPI.Position(StringToName(name));
  }

  public func Duration(name: String) -> Float {
    return AudioXLNative.Duration(StringToName(name));
  }

  public func PlayingSounds() -> array<String> {
    let names: array<CName> = AudioXLAPI.PlayingSounds();
    let out: array<String>;
    let i: Int32 = 0;
    while i < ArraySize(names) {
      ArrayPush(out, NameToString(names[i]));
      i += 1;
    }
    return out;
  }

  public func CreateEmitter(name: String, x: Float, y: Float, z: Float) -> Bool {
    return AudioXLAPI.CreateEmitter(StringToName(name), new Vector4(x, y, z, 1.0));
  }

  public func MoveEmitter(name: String, x: Float, y: Float, z: Float) -> Bool {
    return AudioXLAPI.MoveEmitter(StringToName(name), new Vector4(x, y, z, 1.0));
  }

  public func AttachEmitter(name: String, entity: ref<GameObject>) -> Bool {
    return AudioXLAPI.AttachEmitter(StringToName(name), entity);
  }

  public func DetachEmitter(name: String) -> Bool {
    return AudioXLAPI.DetachEmitter(StringToName(name));
  }

  public func DestroyEmitter(name: String) -> Bool {
    return AudioXLAPI.DestroyEmitter(StringToName(name));
  }

  public func HasEmitter(name: String) -> Bool {
    return AudioXLAPI.HasEmitter(StringToName(name));
  }

  public func PlayOn(emitter: String, sound: String, opt gain: Float, opt from: Float, opt fadeIn: Float,
                     opt pitch: Float, opt pan: Float, opt delay: Float, opt loop: Bool, opt end: Float) -> Bool {
    return AudioXLAPI.PlayOn(StringToName(emitter), StringToName(sound), gain, from, fadeIn, pitch, pan, delay, loop, end);
  }

  public func SetEmitterPitch(name: String, cents: Float, opt glide: Float) -> Bool {
    return AudioXLAPI.SetEmitterPitch(StringToName(name), cents, glide);
  }

  public func SetEmitterPan(name: String, pan: Float, opt glide: Float) -> Bool {
    return AudioXLAPI.SetEmitterPan(StringToName(name), pan, glide);
  }

  public func StopOn(emitter: String, opt sound: String, opt fadeOut: Float) -> Bool {
    return AudioXLAPI.StopOn(StringToName(emitter), StringToName(sound), fadeOut);
  }

  public func SetEmitterReverb(name: String, bus: String, level: Float) -> Bool {
    return AudioXLAPI.SetEmitterReverb(StringToName(name), StringToName(bus), level);
  }

  public func SetEmitterFilter(name: String, lowPass: Float, highPass: Float) -> Bool {
    return AudioXLAPI.SetEmitterFilter(StringToName(name), lowPass, highPass);
  }

  public func SetEmitterOcclusion(name: String, enabled: Bool, opt floorHz: Float, opt blockedLevel: Float,
                                  opt glide: Float) -> Bool {
    return AudioXLAPI.SetEmitterOcclusion(StringToName(name), enabled, floorHz, blockedLevel, glide);
  }
}
