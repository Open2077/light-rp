AudioXL Source-Available License 1.0

Copyright 2026 DigitalVixen. All rights reserved except as granted below.

This license covers AudioXL: the plugin, its scripts, its tools, its documentation and every
file in its releases ("the Software"), apart from the third-party parts listed at the end, which
keep their own terms.

1. What you may do

- Read the source and build it, for your own use on your own machines.
- Change it for your own use. You may send your changes to the copyright holder (a GitHub pull
  request or a message); by doing so you let the holder use them in the Software under this license.
- Use the Software from your own mods without restriction: calling its script or Lua API, its
  natives, its manifest and sounds.json formats, its event names, its sound types and its volume
  groups and mutes. A mod that depends on AudioXL is your own work, not a derivative of the
  Software, and nothing here applies to it.
- Link to the official download pages, and list the Software as a requirement anywhere.

2. What you may not do

- Publish, upload, host, bundle or otherwise distribute the Software or any part of it, changed
  or unchanged, anywhere. That includes "fixed", "updated", "patched", "ported" and renamed copies,
  mod packs and collections that embed it rather than link to it.
- Make a work from the source, in whole or in part, and distribute that.
- Remove or change this license, the copyright notice or the third-party notices.

3. If the Software goes unmaintained

The point of clause 2 is that the one place to get AudioXL is the author's, not that the mod can
die with the author. So: if twelve consecutive months pass during which

  (a) the most recent official release of the Software does not load or does not work with the
      then-current version of Cyberpunk 2077, and
  (b) the copyright holder publishes neither an updated release nor a public notice that the
      Software is still maintained (on its Nexus Mods page, its GitHub repository or the
      DigitalVixen Discord),

then, on the first day after those twelve months, the most recent official release of the
Software, source and binaries, becomes licensed under the MIT License, with the copyright notice
"Copyright 2026 DigitalVixen", and clause 2 no longer applies to it. The copyright holder may also
relicense the Software under the MIT License earlier, by publishing a notice to that effect.

4. Versions released before this license

Versions of the Software released under the MIT License before this license was adopted stay
under the MIT License. This license applies to every version released with it.

5. No warranty

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Third-party parts

These stay under their own licenses, reproduced or referenced here as those licenses require. They
are not relicensed by this document, and clause 2 does not restrict them beyond their own terms.

The Software links the following libraries, each under the MIT License:

- RedLib (cp2077-red-lib), Copyright (c) 2023 Pavel Siberx (psiberx).
- RED4ext.SDK, Copyright (c) 2020 - present Octavian Dima (WopsS).

It also includes `src/Duration.hpp`, vendored essentially unchanged from Spuddeh's Native Radio
Framework (https://github.com/spuddeh/cp2077-native-radio-framework) under the MIT License,
Copyright (c) 2026 Spuddeh, and used with his permission.

`src/Equalizer.cpp` is ported from RadioXL's equaliser (https://github.com/spuddeh/cp2077-radio-xl,
`plugin/src/Eq.hpp`) under the MIT License, Copyright (c) 2026 Spuddeh.

and bundles these single-header decoders, used under their public domain / MIT-0 terms:

- dr_mp3 and dr_flac (dr_libs), David Reid.
- stb_vorbis (stb), Sean Barrett.

The MIT License, for the parts above and for clause 3:

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
